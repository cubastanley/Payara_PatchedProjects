If needed Jaas jar should be downloaded to this folder.
If needed JDK logging jar should be included here.